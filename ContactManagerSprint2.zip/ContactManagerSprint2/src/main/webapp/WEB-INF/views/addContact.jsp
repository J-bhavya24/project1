<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c"    uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Contact</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        label { display: block; margin-top: 10px; }
        input { padding: 6px; width: 300px; }
        .btn { padding: 8px 16px; background: #4CAF50; color: white;
               border: none; cursor: pointer; border-radius: 4px; margin-top: 15px; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>

<h2>Add New Contact</h2>

<c:if test="${not empty errorMessage}">
    <p class="error">${errorMessage}</p>
</c:if>

<form:form action="/contacts/save" method="post" modelAttribute="contact">
    <label>Name *</label>
    <form:input path="name" placeholder="Enter name" />

    <label>Email *</label>
    <form:input path="email" placeholder="Enter email" />

    <label>Phone</label>
    <form:input path="phone" placeholder="Enter phone" />

    <button type="submit" class="btn">Save Contact</button>
    <a href="/contacts" style="margin-left:10px;">Cancel</a>
</form:form>

</body>
</html>
