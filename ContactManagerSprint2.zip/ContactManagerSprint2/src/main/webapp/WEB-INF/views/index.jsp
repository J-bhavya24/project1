<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Manager</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        .success { color: green; font-weight: bold; }
        .error   { color: red;   font-weight: bold; }
        a.btn { padding: 5px 10px; background: #4CAF50; color: white;
                text-decoration: none; border-radius: 4px; margin-right: 5px; }
        a.btn-danger { background: #e53935; }
    </style>
</head>
<body>

<h2>Contact Manager</h2>

<c:if test="${not empty successMessage}">
    <p class="success">${successMessage}</p>
</c:if>
<c:if test="${not empty errorMessage}">
    <p class="error">${errorMessage}</p>
</c:if>

<a href="/contacts/add" class="btn">+ Add New Contact</a>
<br/><br/>

<c:choose>
    <c:when test="${empty contacts}">
        <p>No contacts found. Add your first contact!</p>
    </c:when>
    <c:otherwise>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Actions</th>
            </tr>
            <c:forEach var="contact" items="${contacts}">
                <tr>
                    <td>${contact.id}</td>
                    <td>${contact.name}</td>
                    <td>${contact.email}</td>
                    <td>${contact.phone}</td>
                    <td>
                        <a href="/contacts/edit/${contact.id}" class="btn">Edit</a>
                        <a href="/contacts/delete/${contact.id}" class="btn btn-danger"
                           onclick="return confirm('Delete this contact?')">Delete</a>
                    </td>
                </tr>
            </c:forEach>
        </table>
    </c:otherwise>
</c:choose>

</body>
</html>
