package com.example.contactmanager.controller;

import com.example.contactmanager.model.Contact;
import com.example.contactmanager.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/contacts")
public class ContactController {

    @Autowired
    private ContactService contactService;

    @GetMapping
    public String listContacts(Model model) {
        model.addAttribute("contacts", contactService.getAllContacts());
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("contact", new Contact());
        return "addContact";
    }

    @PostMapping("/save")
    public String saveContact(@ModelAttribute Contact contact,
                              RedirectAttributes redirectAttributes) {
        try {
            if (contact.getName() == null || contact.getName().trim().isEmpty() ||
                contact.getEmail() == null || contact.getEmail().trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("errorMessage",
                    "Name and Email are required fields!");
                return "redirect:/contacts/add";
            }
            contactService.saveContact(contact);
            redirectAttributes.addFlashAttribute("successMessage",
                "Contact added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                "Error adding contact: " + e.getMessage());
        }
        return "redirect:/contacts";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model,
                               RedirectAttributes redirectAttributes) {
        Optional<Contact> contact = contactService.getContactById(id);
        if (contact.isPresent()) {
            model.addAttribute("contact", contact.get());
            return "editContact";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Contact not found!");
            return "redirect:/contacts";
        }
    }

    @PostMapping("/update")
    public String updateContact(@ModelAttribute Contact contact,
                                RedirectAttributes redirectAttributes) {
        try {
            contactService.saveContact(contact);
            redirectAttributes.addFlashAttribute("successMessage",
                "Contact updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                "Error updating contact: " + e.getMessage());
        }
        return "redirect:/contacts";
    }

    @GetMapping("/delete/{id}")
    public String deleteContact(@PathVariable Long id,
                                RedirectAttributes redirectAttributes) {
        try {
            contactService.deleteContact(id);
            redirectAttributes.addFlashAttribute("successMessage",
                "Contact deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                "Error deleting contact: " + e.getMessage());
        }
        return "redirect:/contacts";
    }
}
