package com.example.contactmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactManagerSprint2Application {
    public static void main(String[] args) {
        SpringApplication.run(ContactManagerSprint2Application.class, args);
    }
}
